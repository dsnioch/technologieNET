﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Drawing;

namespace dawid_snioch
{
    /// <summary>
    /// Interaction logic for ProductEditWindow.xaml
    /// </summary>
    public partial class ProductEditWindow : Window
    {
        Data editedData;
        Window parentWindow;
        String connectionString = @"Data Source=155.158.112.31;Initial Catalog=tomcat;User id=tomcatUser;Password=tomcat;";
        String updateString = "update t_dane set Nr=@nr , Kwota=@kwota, Opis=@opis, Obraz=@obraz where Id=@id ";
        SqlConnection conn;

        public ProductEditWindow()
        {
            InitializeComponent();
        }

        public ProductEditWindow(Data data, Window window)
        {
            parentWindow = window;
            editedData = data;
            this.DataContext = editedData;
            InitializeComponent();
            }


        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            parentWindow.IsEnabled = true;
            conn = new SqlConnection(connectionString);
            update();
        }

        private void update()
        {
            using (SqlCommand command = new SqlCommand(updateString, conn))
            {
                conn.Open();
                command.Parameters.AddWithValue("@id", editedData.Id);
                command.Parameters.AddWithValue("@nr", editedData.Nr);
                command.Parameters.AddWithValue("@tytul", editedData.Tytul);
                command.Parameters.AddWithValue("@opis", editedData.Opis);
                command.Parameters.AddWithValue("@kwota", Convert.ToDecimal(editedData.Kwota));
                command.Parameters.Add("@obraz", SqlDbType.Image, editedData.Obraz.Length).Value = editedData.Obraz;
                command.ExecuteNonQuery();
                conn.Close();
            }
        }


        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            parentWindow.IsEnabled = true;
        }

        private void getImage(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog ofp = new Microsoft.Win32.OpenFileDialog();

            ofp.DefaultExt = ".jpg";
            ofp.Filter = "Obrazy (*.jpg, *.jpeg, *.jpe, *.jfif, *.png) | *.jpg; *.jpeg; *.jpe; *.jfif; *.png";
            Nullable<bool> result = ofp.ShowDialog();
            if (result.HasValue && result.Value)
            {
                string fileName = ofp.FileName;
                System.Windows.Media.ImageSource bitmap = new BitmapImage(new Uri(fileName));
                Obraz.Source = bitmap;
            }
        }

        private ImageSource GetBitmapImageFromBytes(byte[] byteImage)
        {
            BitmapImage biImg = new BitmapImage();
            MemoryStream ms = new MemoryStream(byteImage);
            biImg.BeginInit();
            biImg.StreamSource = ms;
            biImg.EndInit();
            return  biImg as ImageSource;
        }

        public static byte[] ImageToByte(System.Drawing.Image img)
        {
            using (var stream = new MemoryStream())
            {
                img.Save(stream, System.Drawing.Imaging.ImageFormat.Png);
                return stream.ToArray();
            }
        }
    }
}
