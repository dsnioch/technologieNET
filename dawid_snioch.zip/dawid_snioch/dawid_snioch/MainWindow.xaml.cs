﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace dawid_snioch
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<Data> dataList { get; set; }
        Data selectedRow { get; set; }

        String connectionString = @"Data Source=155.158.112.31;Initial Catalog=tomcat;User id=tomcatUser;Password=tomcat;";
        String findAll = "select * from t_dane";

        public MainWindow()
        {
            dataList = new ObservableCollection<Data>();
            InitializeComponent();
        }

        public List<Data> loadData()
        {
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            List<Data> rows = new List<Data>();
            sqlConnection.Open();
            using (SqlCommand command = new SqlCommand(findAll, sqlConnection))
            {
                SqlDataReader dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    Data row = new Data(
                        (dataReader["id"] != null) ? (long)dataReader["id"] : -1L,
                        (dataReader["nr"] != null) ? (String)dataReader["nr"] : "",
                        (dataReader["kwota"] != null) ? (Decimal)dataReader["kwota"] : 0.00m,
                        (dataReader["tytul"] != null) ? (String)dataReader["tytul"] : "",
                        (dataReader["opis"] != null) ? (String)dataReader["opis"] : "",
                        (!dataReader.IsDBNull(dataReader.GetOrdinal("obraz"))) ? (Byte[])dataReader["obraz"] : null);
                    rows.Add(row);
                }
                dataReader.Close();
            }
            return rows;
        }

        private void loadData(object sender, RoutedEventArgs e)
        {
            List<Data> rows = loadData();
            dataList.Clear();
            foreach (Data row in rows)
            {
                dataList.Add(row);
            }
            DataGrid1.ItemsSource = dataList;
        }

        private void editData(object sender, RoutedEventArgs e)
        {
            Data data = (Data)DataGrid1.SelectedItem;
            ProductEditWindow productEdit = new ProductEditWindow(data, this);
            this.IsEnabled = false;
            productEdit.Show();
        }
    }
}
