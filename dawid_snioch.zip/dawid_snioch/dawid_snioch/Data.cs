﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dawid_snioch
{
    public class Data
    {
        public long Id { get; set; }
        public String Nr { get; set; }
        public Decimal Kwota { get; set; }
        public String Opis { get; set; }
        public String Tytul { get; set; }
        public Byte[] Obraz { get; set; }

        public Data(long id, String nr, Decimal kwota, String tytul, String opis, Byte[] obraz)
        {
            this.Id = id;
            this.Nr = nr;
            this.Kwota = kwota;
            this.Tytul = tytul;
            this.Opis = opis;
            this.Obraz = obraz;
        }
    }
}
